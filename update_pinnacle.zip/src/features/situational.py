"""Situational features — game-context patterns from scores and travel.

Feature groups (shift(1) = strictly prior games, no lookahead):

  ONE-RUN GAMES (regression signal)
    one_run_win_rate_l30   : win rate in 1-run games (high rate → regresses)
    one_run_game_pct_l30   : fraction of games decided by 1 run (bullpen/luck)

  BLOWOUT / SHUTOUT (run distribution edges)
    blowout_win_rate_l30   : % of wins by 5+ runs (dominance vs close wins)
    shutout_rate_l30       : rate of scoring 0 runs (volatile offense signal)
    blowout_loss_rate_l30  : % of losses by 5+ runs (defensive vulnerability)

  TIMEZONE TRAVEL (situational fatigue)
    tz_change              : 1 if team changed timezone vs previous game, else 0
    tz_zones_crossed       : number of timezone zones crossed (0-3)
    games_since_tz_change  : games since last timezone change (resets on travel)

Output: data/processed/features_situational.parquet
  game_pk | side (home/away) | all feature columns

Run standalone:
  python -m src.features.situational
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

PROCESSED = Path("data/processed")
OUT = PROCESSED / "features_situational.parquet"

WINDOW = 30
MIN_P = 10

# State → timezone offset from ET (Eastern = 0, Central = -1, Mountain = -2, Pacific = -3)
_STATE_TZ: dict[str, int] = {
    # Eastern
    "MD": 0, "DC": 0, "NY": 0, "PA": 0, "OH": 0, "MI": 0, "IN": 0,
    "GA": 0, "FL": 0, "NC": 0, "TN": 0, "VA": 0, "WV": 0, "CT": 0,
    "MA": 0, "NJ": 0, "DE": 0, "ON": 0,  # Toronto
    # Central
    "IL": 1, "WI": 1, "MN": 1, "MO": 1, "IA": 1, "TX": 1, "LA": 1,
    "AR": 1, "OK": 1, "KS": 1, "MS": 1, "AL": 1, "NE": 1, "SD": 1, "ND": 1,
    # Mountain
    "CO": 2, "AZ": 2, "NM": 2, "UT": 2, "ID": 2, "MT": 2, "WY": 2, "NV": 2,
    # Pacific
    "CA": 3, "WA": 3, "OR": 3,
}


def _venue_tz(state: str | None) -> int | None:
    """Return timezone bucket (0=ET … 3=PT) or None for international venues."""
    if not state or pd.isna(state):
        return None
    return _STATE_TZ.get(str(state).strip().upper())


def build() -> Path:
    games = pd.read_parquet(PROCESSED / "games.parquet")
    games["game_date"] = pd.to_datetime(games["game_date"])
    games = games.dropna(subset=["home_team_abbrev", "away_team_abbrev",
                                  "home_score", "away_score"])
    games["home_win"] = (games["home_score"] > games["away_score"]).astype(int)
    games["run_margin"] = (games["home_score"] - games["away_score"]).abs()
    games["tz"] = games["venue_state"].map(_venue_tz)

    # ── Build per-team game timeline ──────────────────────────────────────────
    rows = []
    for _, r in games.iterrows():
        hw = int(r["home_win"])
        margin = float(r["run_margin"])
        tz = r["tz"]

        for side, team, won in [("home", r["home_team_abbrev"], hw == 1),
                                 ("away", r["away_team_abbrev"], hw == 0)]:
            runs = float(r["home_score"] if side == "home" else r["away_score"])
            rows.append({
                "team": team,
                "game_pk": r["game_pk"],
                "game_date": r["game_date"],
                "won": float(won),
                "runs_scored": runs,
                "margin": margin,
                "is_one_run":   float(margin == 1),
                "one_run_win":  float(margin == 1 and won),
                "is_blowout_win":  float(margin >= 5 and won),
                "is_blowout_loss": float(margin >= 5 and not won),
                "is_shutout":      float(runs == 0),
                "venue_tz": tz,
            })

    tdf = pd.DataFrame(rows)
    tdf = tdf.sort_values(["team", "game_date", "game_pk"]).reset_index(drop=True)

    # ── Timezone travel features (vectorized) ────────────────────────────────
    tdf["prev_tz"] = tdf.groupby("team")["venue_tz"].shift(1)
    valid = tdf["venue_tz"].notna() & tdf["prev_tz"].notna()
    tdf["tz_change"] = 0.0
    tdf["tz_zones_crossed"] = 0.0
    tdf.loc[valid, "tz_change"] = (
        tdf.loc[valid, "venue_tz"] != tdf.loc[valid, "prev_tz"]
    ).astype(float)
    tdf.loc[valid, "tz_zones_crossed"] = (
        tdf.loc[valid, "venue_tz"] - tdf.loc[valid, "prev_tz"]
    ).abs()

    # games_since_tz_change: iterate per team
    gstc_all = []
    for _, grp in tdf.groupby("team", sort=False):
        counter = 0
        vals = []
        for chg in grp["tz_change"]:
            counter = 1 if chg == 1.0 else min(counter + 1, 15)
            vals.append(float(counter))
        gstc_all.append(pd.Series(vals, index=grp.index))
    tdf["games_since_tz_change"] = pd.concat(gstc_all).sort_index()
    tdf.drop(columns=["prev_tz"], inplace=True)

    # ── Rolling features (shift(1) for no lookahead) ─────────────────────────
    def _roll(series: pd.Series, w: int = WINDOW) -> pd.Series:
        return series.shift(1).rolling(w, min_periods=MIN_P).mean()

    def _roll_cond(num: pd.Series, denom: pd.Series, w: int = WINDOW) -> pd.Series:
        """Rolling mean of num/denom only over games where denom==1."""
        ratio = num.where(denom == 1)
        return ratio.shift(1).rolling(w, min_periods=5).mean()

    grp = tdf.groupby("team", group_keys=False)

    tdf["one_run_game_pct_l30"]  = grp["is_one_run"].transform(lambda x: _roll(x))
    tdf["one_run_win_rate_l30"]  = grp.apply(
        lambda g: _roll_cond(g["one_run_win"], g["is_one_run"])
    ).reset_index(level=0, drop=True)
    tdf["blowout_win_rate_l30"]  = grp["is_blowout_win"].transform(lambda x: _roll(x))
    tdf["blowout_loss_rate_l30"] = grp["is_blowout_loss"].transform(lambda x: _roll(x))
    tdf["shutout_rate_l30"]      = grp["is_shutout"].transform(lambda x: _roll(x))

    feat_cols = [
        "one_run_game_pct_l30", "one_run_win_rate_l30",
        "blowout_win_rate_l30", "blowout_loss_rate_l30",
        "shutout_rate_l30",
        "tz_change", "tz_zones_crossed", "games_since_tz_change",
    ]

    # ── Join back to game_pk × side ──────────────────────────────────────────
    gm_teams = games[["game_pk", "home_team_abbrev", "away_team_abbrev"]].copy()

    home_side = (
        tdf.merge(gm_teams, left_on=["game_pk", "team"],
                  right_on=["game_pk", "home_team_abbrev"], how="inner")
        [["game_pk"] + feat_cols].assign(side="home")
    )
    away_side = (
        tdf.merge(gm_teams, left_on=["game_pk", "team"],
                  right_on=["game_pk", "away_team_abbrev"], how="inner")
        [["game_pk"] + feat_cols].assign(side="away")
    )

    out = pd.concat([home_side, away_side], ignore_index=True)
    out.to_parquet(OUT, index=False)

    nan_frac = out[feat_cols].isna().mean()
    print(f"wrote {OUT}  ({len(out):,} rows, {len(feat_cols)} features x 2 sides)")
    print("NaN fractions:\n", nan_frac.round(3).to_string())
    print("\nSample means:")
    print(out[feat_cols].mean().round(3).to_string())
    return OUT


if __name__ == "__main__":
    build()
